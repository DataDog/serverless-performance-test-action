exports.handler = () => {
    return {
        statusCode: 200
    };
};
